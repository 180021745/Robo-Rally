package LauncherTest;

import java.util.Random;

import org.junit.Test;

import Simulation.Flag;
import Simulation.Gear;
import Simulation.Location;
import Simulation.Pit;
import Simulation.Robot;

public class GridTestPrint {

	private Flag flag;
	private Robot robot;
	private Pit pit;
	private Gear gear;
	private Location location;
	public String[][] fullBoard = new String[9][9];
	Random random = new Random();
	private int numOfPlayers = 5;

	@Test
	public void printBoard() {
		for (int i = 0; i <= 8; i++) {
			String[] x1 = { ".", ".", ".", ".", ".", ".", ".", ".", "." };
			fullBoard[i] = x1;
		}

		addFlag();
		addPit();
		addGear();

		for (int i = 0; i < fullBoard.length; i++) {
			for (int j = 0; j < fullBoard[i].length; j++) {
				System.out.print(fullBoard[i][j]);
			}
			System.out.print("\n");
			addRobot();
		}
	}

	public void addFlag() {
		for (int i = 1; i < 5; i++) {
			String icon = Integer.toString(i);
			int randPosX = 0;
			int randPosY = 0;
			while (fullBoard[randPosX][randPosY] != ".") {
				randPosX = random.nextInt(8);
				randPosY = random.nextInt(9);
			}
			fullBoard[randPosX][randPosY] = icon;
		}
	}

	public void addGear() {
		for (int i = 0; i < 2; i++) {
			int randPosX = 0;
			int randPosY = 0;
			while (fullBoard[randPosX][randPosY] != ".") {
				randPosX = random.nextInt(8);
				randPosY = random.nextInt(9);
			}
			fullBoard[randPosX][randPosY] = "+";
		}

		for (int i = 0; i < 2; i++) {
			int randPosX = 0;
			int randPosY = 0;
			while (fullBoard[randPosX][randPosY] != ".") {
				randPosX = random.nextInt(8);
				randPosY = random.nextInt(9);
			}
			fullBoard[randPosX][randPosY] = "-";
		}
	}

	public void addPit() {
		for (int i = 0; i < 2; i++) {
			int randPosX = 0;
			int randPosY = 0;
			while (fullBoard[randPosX][randPosY] != ".") {
				randPosX = random.nextInt(8);
				randPosY = random.nextInt(9);
			}
			fullBoard[randPosX][randPosY] = "x";
		}
	}

	public void addRobot() {
		if (numOfPlayers == 1) {
			fullBoard[8][4] = "A";
		} else if (numOfPlayers == 2) {
			fullBoard[8][4] = "A";
			fullBoard[8][5] = "B";
		} else if (numOfPlayers == 3) {
			fullBoard[8][3] = "C";
			fullBoard[8][4] = "A";
			fullBoard[8][5] = "B";
		} else if (numOfPlayers >= 4) {
			fullBoard[8][3] = "C";
			fullBoard[8][4] = "A";
			fullBoard[8][5] = "B";
			fullBoard[8][6] = "D";
		}
	}
}