package UI;

import java.awt.Robot;
import java.util.Scanner;
import Simulation.Location;
import Simulation.Player;

public class Input {
	private Scanner scanner;
	private Robot robot;
	private String[] inputArray;

	public Input(Scanner scanner) {
		System.out.println("Enter your moves: ");

		int i = 0;
		while (i < 5) {
			scanner = new Scanner(System.in);
			String test = scanner.nextLine();
			if (test.equalsIgnoreCase("f") || test.equalsIgnoreCase("b") || test.equalsIgnoreCase("l")
					|| test.equalsIgnoreCase("r") || test.equalsIgnoreCase("u") || test.equalsIgnoreCase("w")) {
				inputArray[i] = test;

				i++;
			} else {
				System.out.println("Invalid move, Try again.");
			}
		}
	}
}
