package UI;

import static org.junit.Assert.*;

import java.util.Scanner;

import org.junit.Before;
import org.junit.Test;

import Simulation.Player;

public class InputTest {

	private Scanner scanner;
	private Player player1;
	private String[] inputArray;

	@Test
	public void Input() {
		inputArray = new String[5];
		System.out.println("Enter your moves: ");
//		player1 = player1.getRobotID();

		int i = 0;
		while (i < 5) {
			scanner = new Scanner(System.in);
			String test = scanner.nextLine();
			if (test.equalsIgnoreCase("f") || test.equalsIgnoreCase("b") || test.equalsIgnoreCase("l")
					|| test.equalsIgnoreCase("r") || test.equalsIgnoreCase("u") || test.equalsIgnoreCase("w")) {
				inputArray[i] = test;
				i++;
			} else {
				System.out.println("Invalid move, Try again.");
			}
		}
	}
}