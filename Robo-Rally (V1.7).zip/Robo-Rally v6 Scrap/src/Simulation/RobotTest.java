package Simulation;

import static org.junit.Assert.*;

import java.awt.Robot;

import org.junit.Before;
import org.junit.Test;

public class RobotTest {
	private String robotID;

	public RobotTest() {
		setRobotID();
	}

	public void setRobotID() {
		int i = 1;
		String ID = Integer.toString(i);
		robotID = "00" + ID;
	}

	public String getRobotID() {
		return robotID;
	}

	@Test
	public void test() {
		System.out.println(robotID);
	}
}