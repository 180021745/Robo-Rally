package Simulation;


import javax.tools.DocumentationTool.Location;

import IO.Grid;

public class BoardSimulation {

	private Grid grid;

	private Flag nextFlag ;
	private Location startingPosition;

	public void main () {
		grid = new Grid();
	}

	public BoardSimulation (Location startingPosition) {
		this.startingPosition = startingPosition;

	}

	public boolean isNextFlag () {
		return false;
	}
}