package Simulation;
//import java.util.Arrays;

import java.util.Random;

import IO.Grid;

/**
 * Version 1 Single Player Version Written By: Ishmail, Tyler and Reed
 */

public class Robot extends Player {

	/**
	 * Initialising robots location and ID
	 */

	private Location location;
	private String robotID;
	private Grid grid;
	Random random = new Random();
	private int numOfPlayers = 5;
//	private int flagCount;
//	private String startingPosition;
//	private String[] robot1;
//	private String[] player2;
//	private String[] player3;
//	private String[] player4;

	/**
	 * @param robotID
	 * @param location
	 */

	public Robot(String robotID, Location location) {
		super(robotID, location);
//		player2 = new String[5];
//		player3 = new String[5];
//		player4 = new String[5];
		/**
		 * assigns robot object with name and location on board
		 */
	}

	public Location getLocation() {
		return location;
	}

	// Location getters and setter.

	public void setLocation(Location location) {
		this.location = location;
	}

	public void touchFlag() {

	}

	public void setWin() {

	}

	public void pushRobot() {

	}

	public boolean completedAction() {
		return true;
	}

	public void addRobot() {

		if (numOfPlayers == 1) {
			grid.fullBoard[8][4] = "A";
		} else if (numOfPlayers == 2) {
			grid.fullBoard[8][4] = "A";
			grid.fullBoard[8][5] = "B";
		} else if (numOfPlayers == 3) {
			grid.fullBoard[8][3] = "C";
			grid.fullBoard[8][4] = "A";
			grid.fullBoard[8][5] = "B";
		} else if (numOfPlayers >= 4) {
			grid.fullBoard[8][3] = "C";
			grid.fullBoard[8][4] = "A";
			grid.fullBoard[8][5] = "B";
			grid.fullBoard[8][6] = "D";
		}
	}

	public void setRobotID() {
		int i = 1;
		String ID = Integer.toString(i);
		robotID = "00" + ID;
	}

	public String getRobotID() {
		return robotID;
	}

	/*
	 * public String[] getPlayer1() { return player1; }
	 **/
}
