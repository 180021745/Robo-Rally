package Simulation;

public class Player {

	private String playerID;
	private Robot robotID;

	public Player(String iD, Location location) {
		robotID = new Robot(iD, location);
	}

	public void remove() {
		// Game over for dead player after 3 lives
	}

	public void setPlayerID(String playerID) {
		this.playerID = playerID;
	}

	public String getPlayerID() {
		return playerID;
	}

	public boolean hasToken() {
		return false;
	}

//	public Player nextPlayer() {
//		return playerID;
//	}

}
