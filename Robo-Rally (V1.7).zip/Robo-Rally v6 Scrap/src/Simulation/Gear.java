package Simulation;
import java.util.Random;

import IO.Grid;

public class Gear {

	private boolean slotResolved;
	private Grid grid;
	Random random = new Random();

	public boolean isSlotResolved() {
		return slotResolved;
	}

	public void setSlotResolved(boolean slotResolved) {
		this.slotResolved = slotResolved;
	}

	public void rotateRobot() {

	}

	public void addGear() {
		for (int i = 0; i < 2; i++) {
			int randPosX = 0;
			int randPosY = 0;
			while(grid.fullBoard[randPosX][randPosY] != "."){
				randPosX = random.nextInt(8);
				randPosY = random.nextInt(9);
			}
			grid.fullBoard[randPosX][randPosY] = "+";
		}

		for (int i = 0; i < 2; i++) {
			int randPosX = 0;
			int randPosY = 0;
			while(grid.fullBoard[randPosX][randPosY] != "."){
				randPosX = random.nextInt(8);
				randPosY = random.nextInt(9);
			}
			grid.fullBoard[randPosX][randPosY] = "-";
		}
	}
}