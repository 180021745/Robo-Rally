package Simulation;
import java.util.Random;

import IO.Grid;


public class Pit {

	private Grid grid;
	Random random = new Random();


	public boolean hasRobot () {
		return false;

	}

	public void setRobot () {

	}

	public void destroyRobot () {

	}

	public void addPit() {
		for (int i = 0; i < 2; i++) {
			int randPosX = 0;
			int randPosY = 0;
			while(grid.fullBoard[randPosX][randPosY] != "."){
				randPosX = random.nextInt(8);
				randPosY = random.nextInt(9);
			}
			grid.fullBoard[randPosX][randPosY] = "x";
		}
	}
}