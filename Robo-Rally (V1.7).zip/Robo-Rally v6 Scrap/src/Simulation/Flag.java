package Simulation;
import java.util.Random;

import IO.Grid;


public class Flag {

	private Grid grid;
	Random random = new Random();

	public boolean hasRobot() {
		return false;
	}

	public void notfiyBoard () {

	}

	public void addFlag() {
		for (int i = 1; i < 5; i++) {
			String icon = Integer.toString(i);
			int randPosX = 0;
			int randPosY = 0;
			while(grid.fullBoard[randPosX][randPosY] != "."){
				randPosX = random.nextInt(8);
				randPosY = random.nextInt(9);
			}
			grid.fullBoard[randPosX][randPosY] = icon;
		}
	}
}
