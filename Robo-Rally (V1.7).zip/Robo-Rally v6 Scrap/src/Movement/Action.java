package Movement;


public class Action {
	
	public Action() {
		
	}
	
	public void move() {
		
	}

}
