package Movement;


public class UTurn {
	
	private static final Object RobotID = null;
	private char U;
	private boolean complete = true;
	
	public UTurn() {
		
	}
	
	public Object getRobotID () {
		return RobotID;
	}
	
	public void passToken () {
		
	}
	
	public boolean actionComplete () {
		return complete;
		
	}
	

}
