package Movement;


public class Backward {
	
	private static final Object RobotID = null;
	private char B;
	private boolean complete = true;
	
	public Object getRobotID () {
		return RobotID;
	}
	
	public void passToken () {
		
	}
	
	public Backward() {
		
	}
	
	
}
