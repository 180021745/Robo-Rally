package Simulation;


public class Gears {
	
	private boolean slotResolved;

	public boolean isSlotResolved() {
		return slotResolved;
	}

	public void setSlotResolved(boolean slotResolved) {
		this.slotResolved = slotResolved;
	}
	
	public void rotateRobot() {
		
	}

}
