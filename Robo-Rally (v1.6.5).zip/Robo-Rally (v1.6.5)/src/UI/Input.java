package UI;

import java.util.Scanner;

//import Simulation.Robots;

public class Input {
	private Scanner scanner;
//	private Robots robots;
	private String[] player1;
	
	public Input(Scanner scanner) {
/*		robots.getPlayer1();
*/	
		player1 = new String[5];
		
		System.out.println("Enter your moves: ");
		//while (input < 5)
			scanner = new Scanner(System.in);
			player1[0] = scanner.nextLine();
			//i++
		scanner.close();
			
			
//		
	}
}
