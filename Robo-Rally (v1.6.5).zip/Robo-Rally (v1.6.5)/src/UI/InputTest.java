package UI;

import static org.junit.Assert.*;

import java.util.Scanner;

import org.junit.Before;
import org.junit.Test;

public class InputTest {

	private Scanner scanner;
	private String[] player1;

	@Test
	public void Input() {
		player1 = new String[5];
		System.out.println("Enter your moves: ");

//		for (int i = 0; i < 5; i++) {
//			scanner = new Scanner(System.in);
//			String test = scanner.nextLine();
//			if (test.equalsIgnoreCase("f") || test.equalsIgnoreCase("b") || test.equalsIgnoreCase("l")
//					|| test.equalsIgnoreCase("r") || test.equalsIgnoreCase("u") || test.equalsIgnoreCase("w")) {
//			} else {
//				System.out.println("Invalid move, Try again.");
//				scanner = new Scanner(System.in);
//				test = scanner.nextLine();
//			}
//			player1[i] = test;
//		}
		int i = 0;
		while (i < 5) {
			scanner = new Scanner(System.in);
			String test = scanner.nextLine();
			if (test.equalsIgnoreCase("f") || test.equalsIgnoreCase("b") || test.equalsIgnoreCase("l")
					|| test.equalsIgnoreCase("r") || test.equalsIgnoreCase("u") || test.equalsIgnoreCase("w")) {
				player1[i] = test;
				i++;
			} else {
				System.out.println("Invalid move, Try again.");
			}
		}
		System.out.println("Your moves are: " + player1[0] + player1[1] + player1[2] + player1[3] + player1[4]);
//		System.out.println(player1[0]);
	}
}