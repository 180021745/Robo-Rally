package EmptyClasses;

import java.lang.reflect.Array;

public class LocationType {
	
	private String actorsList[] ;
	
	private LocationType (random) {
		
	}

	public void getRow() {
		
	}
	
	public void getColumn () {
		
	}
	
	public void getLocation () {
		
	}
	
	public void add () {
		
	}
	
	public void remove () {
		
	}
	
	public String getActorslist[];{
		
	}
	
	

}
