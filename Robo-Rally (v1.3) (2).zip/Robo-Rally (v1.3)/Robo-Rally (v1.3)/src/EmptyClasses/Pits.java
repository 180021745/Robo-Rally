package EmptyClasses;

public class Pits {
	
	public boolean hasRobot () {
		return false;
		
	}
	
	public void setRobot () {
		
	}
	
	public void destroyRobot () {
		
	}

}
