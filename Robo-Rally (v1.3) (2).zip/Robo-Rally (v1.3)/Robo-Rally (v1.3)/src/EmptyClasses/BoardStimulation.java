package EmptyClasses;

import javax.tools.DocumentationTool.Location;

public class BoardStimulation {
	 
	private void nextFlag (flag);
	private Location startingPosition;
	
	public void main () {
		
	}
	
	public BoardStimulation (Location startingPosition) {
		this.startingPosition = startingPosition;
		
	}
	
	public boolean isNextFlag () {
		
	}
	

}
