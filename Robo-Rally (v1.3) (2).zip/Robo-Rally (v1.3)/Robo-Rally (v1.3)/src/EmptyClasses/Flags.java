package EmptyClasses;

public class Flags {
	
	public boolean hasRobot() {
		return false;
		
	}
	
	public void notfiyBoard () {
		
	}

}
