import java.util.Random;
import java.lang.reflect.Array;

public class Location {
	// Row and column positions.
	private int row;
	private int col;
	private Location location;
	private String actorsList[];
	private Random random;

	/**
	 * Represent a row and column.
	 *
	 * @param row
	 *            The row.
	 * @param col
	 *            The column.
	 */
	public Location(int row, int col) {
		this.row = row;
		this.col = col;
		random = new Random();
	}

	/**
	 * @return The row.
	 */
	public int getRow() {
		return row;
	}

	/**
	 * @return The column.
	 */
	public int getCol() {
		return col;
	}

	public Location getLocation() {
		return location;
	}

	public void add() {

	}

	public void remove() {

	}

	public String getActorslist[];
	{

	}
}
