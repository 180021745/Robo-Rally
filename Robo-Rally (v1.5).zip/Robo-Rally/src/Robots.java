//import java.util.Arrays;

/**
 * Version 1 Single Player Version Written By: Ishmail, Tyler and Reed
 */

public class Robots {

	/**
	 * Initialising robots location and ID
	 */

	private Location location;
	private String iD;
	private int flagCount;
	private String startingPosition;

	/**
	 * @param robotID
	 * @param location
	 */

	public Robots(String robotID, Location location) {
		this.iD = robotID;
		this.location = location;
		/**
		 * assigns robot object with name and location on board
		 */
	}

	public Location getLocation() {
		return location;
	}

	// Location getters and setter.

	public void setLocation(Location location) {
		this.location = location;
	}

	public void touchFlag() {

	}

	public void setWin() {

	}

	public void pushRobot() {

	}

	public boolean completedAction() {
		return true;
	}
}
