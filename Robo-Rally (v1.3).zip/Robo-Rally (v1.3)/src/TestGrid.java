import java.util.Arrays;

import org.junit.Test;

public class TestGrid {

/**	@Test
*	Initial test of printing all data on a single line.
*	Written By: Ishmail, Muhammad
*
*	public void printBoard() {
*		String[] x1 = {".", ".", ".", ".", ".", ".", ".", ".", "."};
*		String[] x2 = {".", ".", ".", ".", ".", ".", ".", ".", "."};
*		String[] x3 = {".", ".", ".", ".", ".", ".", ".", ".", "."};
*		String[] x4 = {".", ".", ".", ".", ".", ".", ".", ".", "."};
*		String[] x5 = {".", ".", ".", ".", ".", ".", ".", ".", "."};
*		String[] x6 = {".", ".", ".", ".", ".", ".", ".", ".", "."};
*		String[] x7 = {".", ".", ".", ".", ".", ".", ".", ".", "."};
*		String[] x8 = {".", ".", ".", ".", ".", ".", ".", ".", "."};
*		String[] x9 = {".", ".", ".", ".", ".", ".", ".", ".", "."};
*		
*		String[][] fullBoard = {x1, x2, x3, x4, x5, x6, x7, x8, x9};
*
*		System.out.println(Arrays.deepToString(fullBoard));
*	}
*/

	/**
	 *  Written By: Ishmail, Muhammad
	 *  Attempting to draw 9x9 grid.
	 *  9 rows and 9 columns.
	 */
/**	@Test
*	public void printBoard2() {
*		String[] x1 = {".", ".", ".", ".", ".", ".", ".", ".", "."};
*		String[] x2 = {".", ".", ".", ".", ".", ".", ".", ".", "."};
*		String[] x3 = {".", ".", ".", ".", ".", ".", ".", ".", "."};
*		String[] x4 = {".", ".", ".", ".", ".", ".", ".", ".", "."};
*		String[] x5 = {".", ".", ".", ".", ".", ".", ".", ".", "."};
*		String[] x6 = {".", ".", ".", ".", ".", ".", ".", ".", "."};
*		String[] x7 = {".", ".", ".", ".", ".", ".", ".", ".", "."};
*		String[] x8 = {".", ".", ".", ".", ".", ".", ".", ".", "."};
*		String[] x9 = {".", ".", ".", ".", ".", ".", ".", ".", "."};
*	
*		String[][] fullBoard = {x1, x2, x3, x4, x5, x6, x7, x8, x9};
*
*		for (int i = 0; i < fullBoard.length; i++) {
*			System.out.println(fullBoard[i]);
*		}
*	}
*}
*/
	
	/**
	 * Written By: Ishmail, Reed
	 * Attempting to draw 9x9 grid.
	 * Refactored
	 */
	@Test
	public void printBoard3() {
		String[][] fullBoard = new String[9][];

		for (int i = 0; i <= 8; i++) {
			String[] x1 = {".", ".", ".", ".", ".", ".", ".", ".", "."};			
			fullBoard[i] = x1;
		}

		for (int i = 0; i < fullBoard.length; i++) {
			for (int j = 0; j < fullBoard[i].length; j++) {
				System.out.print(fullBoard[i][j]);
			}
			System.out.print("\n");
		}
		
	}
	}