/**
 * Written by: Ishmail, Reed, Tyler
 * Version 2 implementation (Refactored)
 * Single Player version
 */

//import java.util.Scanner;
//import java.io.File;
//import java.util.Random;

public class Grid {
	
//	private Scanner scanner;
	private Location location;
//	private Random generator;
		
	private int pX;
	private int pY;
	
	/**
	 * Scanner reads the filename of board file
	 * Stores to scanner
	 */
	
	public Grid() {
//		scanner = new Scanner(System.in);
		location = new Location(pX, pY);
//		generator = new Random();
		
/**		String[] x2 = {".", ".", ".", ".", ".", ".", ".", ".", "."};
*		String[] x3 = {".", ".", ".", ".", ".", ".", ".", ".", "."};
*		String[] x4 = {".", ".", ".", ".", ".", ".", ".", ".", "."};
*		String[] x5 = {".", ".", ".", ".", ".", ".", ".", ".", "."};
*		String[] x6 = {".", ".", ".", ".", ".", ".", ".", ".", "."};
*		String[] x7 = {".", ".", ".", ".", ".", ".", ".", ".", "."};
*		String[] x8 = {".", ".", ".", ".", ".", ".", ".", ".", "."};
*		String[] x9 = {".", ".", ".", ".", ".", ".", ".", ".", "."};
*		
*		String[][] fullBoard = {x1, x2, x3, x4, x5, x6, x7, x8, x9};
*/		
		
		/**
		 * Create Array of arrays that holds full 9x9 board
		 */
		String[][] fullBoard = new String[9][];
		
		
		/**
		 * Written By: Ishmail and Reed
		 * Loop adding array of 9 'blank' spaces into array until a total of 9 have been added 
		 */
		for (int i = 0; i <= 8; i++) {
			String[] x1 = {".", ".", ".", ".", ".", ".", ".", ".", "."};
			
//			random number generator (between 0 - 8, loop twice to generate X and Y position)
//			int x = generator.nextInt(8);
//			int y = generator.nextInt(8);
			
			
			fullBoard[i] = x1;
		}

		for (int i = 0; i < fullBoard.length; i++) {
			for (int j = 0; j < fullBoard[i].length; j++) {
				System.out.println(fullBoard[i][j]);
			}
			System.out.print("\n");
		}
		
		
//		System.out.println(Arrays.deepToString(fullBoard));
		
/**		for (int i = 0; i < 82; i++) {
*			File file = new File(#FILE EXTENSION#);
*			Scanner boardLayout = new Scanner(file);
*			while (boardLayout.hasNextLine()){
*				
*				System.out.println(boardLayout.nextline());
*				}
*			}
*
*
*/	}
	/**
	 * Above commented is execution with pre-selected file of board layout
	 */

	/**
	 * Print board layout from input
	 */
//	public void printBoard() {
//		System.out.print(scanner.nextLine());
//	}

	public Location startingPosition() {
//		int pX = location.getRow();
//		int pY = location.getCol();
		return location;
	}
	
}

