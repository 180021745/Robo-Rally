package EmptyClasses;

public class RotateLeft {

}
