package EmptyClasses;

public class Wait {

}
