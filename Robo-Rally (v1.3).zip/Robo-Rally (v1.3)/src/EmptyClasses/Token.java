package EmptyClasses;

public class Token {

}
