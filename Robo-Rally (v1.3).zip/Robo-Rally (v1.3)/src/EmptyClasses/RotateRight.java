package EmptyClasses;

public class RotateRight {

}
