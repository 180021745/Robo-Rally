package EmptyClasses;

public class LocationType {

}
