package EmptyClasses;

public class BoardStimulation {

}
