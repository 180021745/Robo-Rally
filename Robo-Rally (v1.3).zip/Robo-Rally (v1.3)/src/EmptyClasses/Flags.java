package EmptyClasses;

public class Flags {

}
