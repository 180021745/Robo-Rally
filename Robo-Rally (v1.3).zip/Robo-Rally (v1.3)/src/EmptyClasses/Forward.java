package EmptyClasses;

public class Forward {

}
