package EmptyClasses;

public class Gears {

}
