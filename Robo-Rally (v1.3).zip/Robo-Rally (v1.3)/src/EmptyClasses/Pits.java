package EmptyClasses;

public class Pits {

}
