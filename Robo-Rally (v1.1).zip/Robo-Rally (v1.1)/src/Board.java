/**
 * Written by: Ishmail, Reed, Tyler
 * Version 2 implementation
 * Single Player version
 */

import java.util.Scanner;
//import java.io.File;

public class Board {
	
	private Scanner scanner;
	
	/**
	 * Scanner reads the filename of board file
	 * Stores to scanner
	 */
	
	public Board() {
		scanner = new Scanner(System.in);
		//File file = new File(#FILE EXTENSION#);
		//Scanner boardLayout = new Scanner(file);
		//while (boardLayout.hasNextLine()){
		//	System.out.println(boardLayout.nextline());
		//	}
	}
	/**
	 * Above commented is execution with pre-selected file of board layout
	 */

	/**
	 * Print board layout from input
	 */
	public void printBoard() {
		System.out.print(scanner.nextLine());
	}

}
