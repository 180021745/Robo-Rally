package UI;

import java.util.Scanner;

import Simulation.Location;
import Simulation.Player;
import Simulation.Robots;

//import Simulation.Robots;

public class Input {
	private Scanner scanner;
	private Player player1;
	private Location location;
//	private Robots[] player1;
//	private String[] player1;
	
	public Input(Scanner scanner) {
//		player1 = new Robots[5];
//		player1 = new String[5];
		System.out.println("Enter your moves: ");

		int i = 0;
		while (i < 5) {
			scanner = new Scanner(System.in);
			String test = scanner.nextLine();
			if (test.equalsIgnoreCase("f") || test.equalsIgnoreCase("b") || test.equalsIgnoreCase("l")
					|| test.equalsIgnoreCase("r") || test.equalsIgnoreCase("u") || test.equalsIgnoreCase("w")) {
				player1.getRobot[i] = test;
				i++;
			} else {
				System.out.println("Invalid move, Try again.");
			}
		}
		System.out.println("Your moves are: " + player1[0] + player1[1] + player1[2] + player1[3] + player1[4]);
	}
/*	public Robots getPlayer1() {
*		return player1;
*	}
*/	public void setPlayer1(int playerID, String robotID, Location location) {
		player1 = new Player(playerID,robotID,location);
		}
}
