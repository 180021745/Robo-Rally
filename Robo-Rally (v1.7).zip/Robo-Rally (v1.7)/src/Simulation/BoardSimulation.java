package Simulation;


import javax.tools.DocumentationTool.Location;

public class BoardSimulation {
	 
	private Flags nextFlag ;
	private Location startingPosition;
	
	public void main () {
		
	}
	
	public BoardSimulation (Location startingPosition) {
		this.startingPosition = startingPosition;
		
	}
	
	public boolean isNextFlag () {
		return false;
	}
	

}
