package Simulation;

public class Player {

	
	private Player playerID;
	private Robots robotID;
	private String[] player; 
	private Robots tyler;

	
	public Player(int playerID,String robotID, Location location) {
		 tyler = new Robots(robotID, location);
	}
	
	public Robots getRobot() {
		return tyler;
		
	}
	

	public void remove() {

	}

	public Robots getRobotID() {
		return robotID;

	}

	public void setRobotID() {

	}

	public void setPlayerID(Player playerID) {
		this.playerID = playerID;
	}

	public Player getPlayerID() {
		return playerID;

	}

	public boolean hasToken() {
		return false;

	}

	public Player nextPlayer() {
		return playerID;

	}

}
