package Simulation;
//import java.util.Arrays;

/**
 * Version 1 Single Player Version Written By: Ishmail, Tyler and Reed
 */

public class Robots {

	/**
	 * Initialising robots location and ID
	 */

	private Location location;
	private String iD;
	private int flagCount;
	private String startingPosition;
	private String[] robot1;
//	private String[] player2;
//	private String[] player3;
//	private String[] player4;

	/**
	 * @param robotID
	 * @param location
	 */

	public Robots(String robotID, Location location) {
		this.iD = robotID;
		this.location = location;
		robot1 = new String[5];
//		player2 = new String[5];
//		player3 = new String[5];
//		player4 = new String[5];
		/**
		 * assigns robot object with name and location on board
		 */
	}

	public Location getLocation() {
		return location;
	}

	// Location getters and setter.

	public void setLocation(Location location) {
		this.location = location;
	}

	public void touchFlag() {

	}

	public void setWin() {

	}

	public void pushRobot() {

	}

	public boolean completedAction() {
		return true;
	}
/*	public String[] getPlayer1() {
*		return player1;
*	}
**/
}

