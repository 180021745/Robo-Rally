package Movement;


public class Actions {
	
	public Actions() {
		
	}
	
	public void move() {
		
	}

}
