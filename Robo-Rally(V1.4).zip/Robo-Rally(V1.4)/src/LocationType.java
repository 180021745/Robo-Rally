

import java.lang.reflect.Array;
import java.util.Random;

public class LocationType {
	
	private String actorsList[] ;
	private Random random;
	
	public LocationType () {
		random = new Random();
	}

	public void getRow() {
		
	}
	
	public void getColumn () {
		
	}
	
	public void getLocation () {
		
	}
	
	public void add () {
		
	}
	
	public void remove () {
		
	}
	
	public String getActorslist[];{
		
	}
	
	

}
