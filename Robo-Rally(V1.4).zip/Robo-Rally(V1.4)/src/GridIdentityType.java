
public class GridIdentityType {

	public GridIdentityType() {
		
	}
	
	public void act() {
		
	}
}
