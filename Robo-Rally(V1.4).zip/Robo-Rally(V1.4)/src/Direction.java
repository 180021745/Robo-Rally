
//public class Direction {
	
	public enum Direction {
		NORTH{
			public Direction turnClockwise() {return EAST;}
			public Direction turnCounterClockwise() {return WEST;}
		},
		
		SOUTH{
			public Direction turnClockwise() {return EAST;}
			public Direction turnCounterClockwise() {return WEST;}
		},
		EAST{
			public Direction turnClockwise() {return EAST;}
			public Direction turnCounterClockwise() {return WEST;}
		},
		WEST{
			public Direction turnClockwise() {return EAST;}
			public Direction turnCounterClockwise() {return WEST;}
		};	
	}

//}
