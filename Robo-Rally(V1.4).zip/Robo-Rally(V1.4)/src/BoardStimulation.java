

import javax.tools.DocumentationTool.Location;

public class BoardStimulation {
	 
	private Flags nextFlag ;
	private Location startingPosition;
	
	public void main () {
		
	}
	
	public BoardStimulation (Location startingPosition) {
		this.startingPosition = startingPosition;
		
	}
	
	public boolean isNextFlag () {
		return false;
	}
	

}
