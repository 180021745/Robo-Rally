

public class RotateRight {
	
	private static final Object RobotID = null;
	private char R;
	private boolean complete = true;
	
	public RotateRight() {
		
	}
	
	public Object getRobotID () {
		return RobotID;
	}
	
	public void passToken () {
		
	}
	
	public boolean actionComplete () {
		return complete;
		
	}
	

}
